"""
╔══════════════════════════════════════════════════════════════╗
║         SQL INSERT VALIDATOR — Validador PL/SQL              ║
║         Versão 1.0 | Analista PL/SQL Tool                    ║
╚══════════════════════════════════════════════════════════════╝

Módulo principal de validação de comandos INSERT SQL.
Suporta múltiplos INSERTs, detecção de erros de sintaxe,
mapeamento coluna→valor e sugestão de correção automática.
"""

import re
import sys
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ─────────────────────────────────────────────────────────────
# ENUMS E CONSTANTES
# ─────────────────────────────────────────────────────────────

class TipoValor(Enum):
    STRING    = "STRING"
    NUMERO    = "NÚMERO"
    DATA      = "DATA"
    NULO      = "NULL"
    BOOLEANO  = "BOOLEANO"
    EXPRESSAO = "EXPRESSÃO/FUNÇÃO"
    DESCONHECIDO = "?"


class StatusValidacao(Enum):
    OK         = "✅ VÁLIDO"
    ERRO       = "❌ INVÁLIDO"
    AVISO      = "⚠️  ATENÇÃO"


# Padrões de datas reconhecidos
PADROES_DATA = [
    r"'\d{4}-\d{2}-\d{2}'",                     # '2024-01-31'
    r"'\d{2}/\d{2}/\d{4}'",                     # '31/01/2024'
    r"'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}'",  # '2024-01-31 10:30:00'
    r"TO_DATE\s*\(.*?\)",                        # TO_DATE(...)
    r"SYSDATE",                                  # SYSDATE
    r"CURRENT_DATE",                             # CURRENT_DATE
    r"NOW\s*\(\s*\)",                            # NOW()
]

SEPARADOR_SIMPLES  = "─" * 62
SEPARADOR_DUPLO    = "═" * 62
SEPARADOR_ASTERISCO = "★" * 62


# ─────────────────────────────────────────────────────────────
# DATACLASSES
# ─────────────────────────────────────────────────────────────

@dataclass
class MapColVal:
    """Representa o par coluna ↔ valor mapeado."""
    coluna: str
    valor: str
    tipo: TipoValor = TipoValor.DESCONHECIDO


@dataclass
class ResultadoValidacao:
    """Resultado completo de um INSERT analisado."""
    sql_original: str
    tabela: str                        = ""
    colunas: list[str]                 = field(default_factory=list)
    valores: list[str]                 = field(default_factory=list)
    mapeamento: list[MapColVal]        = field(default_factory=list)
    status: StatusValidacao            = StatusValidacao.OK
    erros: list[str]                   = field(default_factory=list)
    avisos: list[str]                  = field(default_factory=list)
    sugestao: Optional[str]            = None
    tem_colunas_explicitas: bool       = True


# ─────────────────────────────────────────────────────────────
# INFERÊNCIA DE TIPO DE VALOR
# ─────────────────────────────────────────────────────────────

def inferir_tipo(valor: str) -> TipoValor:
    """Detecta o tipo básico de um valor SQL."""
    v = valor.strip()

    if v.upper() == "NULL":
        return TipoValor.NULO

    if v.upper() in ("TRUE", "FALSE"):
        return TipoValor.BOOLEANO

    # String entre aspas simples
    if v.startswith("'") and v.endswith("'") and len(v) >= 2:
        inner = v[1:-1]
        # Verifica se parece data dentro da string
        for padrao in PADROES_DATA[:2]:
            if re.fullmatch(padrao, v, re.IGNORECASE):
                return TipoValor.DATA
        return TipoValor.STRING

    # Funções / expressões de data
    for padrao in PADROES_DATA[2:]:
        if re.match(padrao, v, re.IGNORECASE):
            return TipoValor.DATA

    # Número (inteiro, decimal, notação científica, negativo)
    if re.fullmatch(r"-?\d+(\.\d+)?([eE][+-]?\d+)?", v):
        return TipoValor.NUMERO

    # Qualquer outra função ou expressão
    if re.search(r"\(", v):
        return TipoValor.EXPRESSAO

    return TipoValor.DESCONHECIDO


# ─────────────────────────────────────────────────────────────
# PARSER DE INSERT
# ─────────────────────────────────────────────────────────────

def _extrair_lista_parenteses(texto: str, pos_inicial: int) -> tuple[list[str], int, str]:
    """
    A partir de pos_inicial, localiza o conteúdo entre parênteses
    e divide respeitando parênteses aninhados e strings com aspas.

    Retorna (itens, pos_fim, erro_msg).
    """
    i = pos_inicial
    n = len(texto)

    # Avança até encontrar '('
    while i < n and texto[i] != '(':
        i += 1

    if i >= n:
        return [], i, "Parêntese de abertura '(' não encontrado."

    i += 1  # pula '('
    nivel    = 1
    em_string = False
    char_str  = ''
    buf      = []
    item_buf = []

    while i < n and nivel > 0:
        c = texto[i]

        if em_string:
            item_buf.append(c)
            if c == char_str and texto[i - 1] != '\\':
                em_string = False
        elif c in ("'", '"'):
            em_string = True
            char_str  = c
            item_buf.append(c)
        elif c == '(':
            nivel += 1
            item_buf.append(c)
        elif c == ')':
            nivel -= 1
            if nivel == 0:
                buf.append(''.join(item_buf).strip())
            else:
                item_buf.append(c)
        elif c == ',' and nivel == 1:
            buf.append(''.join(item_buf).strip())
            item_buf = []
        else:
            item_buf.append(c)

        i += 1

    if nivel != 0:
        return buf, i, "Parêntese de fechamento ')' ausente ou extra."

    # Remove itens vazios resultantes de trailing commas
    buf = [x for x in buf if x]
    return buf, i, ""


def _remover_comentarios(sql: str) -> str:
    """Remove comentários SQL (-- linha e /* bloco */)."""
    sql = re.sub(r'--[^\n]*', '', sql)
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    return sql


def parse_insert(sql: str) -> ResultadoValidacao:
    """
    Faz o parse completo de um INSERT INTO e retorna
    um ResultadoValidacao com todos os dados extraídos.
    """
    resultado = ResultadoValidacao(sql_original=sql.strip())
    sql_clean = _remover_comentarios(sql).strip()

    # ── 1. Verifica se começa com INSERT INTO ──────────────────
    padrao_inicio = re.compile(
        r'^INSERT\s+INTO\s+', re.IGNORECASE
    )
    if not padrao_inicio.match(sql_clean):
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append(
            "O comando não começa com INSERT INTO."
        )
        return resultado

    # ── 2. Extrai nome da tabela ───────────────────────────────
    pos_apos_into = padrao_inicio.match(sql_clean).end()
    resto = sql_clean[pos_apos_into:].strip()

    # Nome da tabela: schema.tabela ou apenas tabela, com ou sem aspas
    padrao_tabela = re.compile(
        r'^("?\w+"?\."?\w+"?|"?\w+"?)\s*', re.IGNORECASE
    )
    m_tabela = padrao_tabela.match(resto)
    if not m_tabela:
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append("Nome de tabela não identificado após INSERT INTO.")
        return resultado

    resultado.tabela = m_tabela.group(1)
    pos = pos_apos_into + m_tabela.end()
    resto = sql_clean[pos:].strip()

    # ── 3. Verifica se há lista de colunas ────────────────────
    tem_colunas = resto.startswith('(')

    # ── 4. Localiza o VALUES ──────────────────────────────────
    padrao_values = re.compile(r'\bVALUES\s*\(', re.IGNORECASE)
    m_values = padrao_values.search(sql_clean, pos)

    if not m_values:
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append(
            "Cláusula VALUES não encontrada. Verifique a sintaxe do INSERT."
        )
        return resultado

    pos_values = m_values.start()

    # ── 5. Extrai colunas (se existirem) ─────────────────────
    if tem_colunas:
        resultado.tem_colunas_explicitas = True
        colunas, pos_col_fim, err_col = _extrair_lista_parenteses(sql_clean, pos)

        if err_col:
            resultado.status = StatusValidacao.ERRO
            resultado.erros.append(f"Erro ao ler lista de colunas: {err_col}")

        resultado.colunas = [c.strip().strip('"').strip("'") for c in colunas if c.strip()]

        # Verifica se realmente há algo entre ) e VALUES
        trecho_entre = sql_clean[pos_col_fim:pos_values].strip()
        if trecho_entre:
            resultado.avisos.append(
                f"Texto inesperado entre lista de colunas e VALUES: '{trecho_entre}'"
            )
    else:
        resultado.tem_colunas_explicitas = False
        resultado.avisos.append(
            "Lista de colunas não informada. "
            "A validação de mapeamento coluna→valor não é possível."
        )

    # ── 6. Extrai valores ─────────────────────────────────────
    pos_valores_inicio = m_values.end() - 1   # recua para o '('
    valores, _, err_val = _extrair_lista_parenteses(sql_clean, pos_valores_inicio)

    if err_val:
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append(f"Erro ao ler lista de valores: {err_val}")

    resultado.valores = [v.strip() for v in valores if v.strip()]

    # ── 7. Verifica terminação do comando ─────────────────────
    trecho_apos = sql_clean[sql_clean.rfind(')') + 1:].strip()
    if trecho_apos and trecho_apos != ';':
        resultado.avisos.append(
            f"Conteúdo após o fechamento do VALUES: '{trecho_apos}'"
        )

    return resultado


# ─────────────────────────────────────────────────────────────
# VALIDAÇÃO DE CONSISTÊNCIA
# ─────────────────────────────────────────────────────────────

def validar_consistencia(resultado: ResultadoValidacao) -> ResultadoValidacao:
    """
    Compara quantidades de colunas vs valores,
    monta o mapeamento e classifica tipos.
    """
    n_col = len(resultado.colunas)
    n_val = len(resultado.valores)

    # Sem colunas explícitas: não há o que comparar
    if not resultado.tem_colunas_explicitas:
        # Ainda assim, mapeia os valores com índice genérico
        resultado.mapeamento = [
            MapColVal(
                coluna=f"COLUNA_{i+1}",
                valor=v,
                tipo=inferir_tipo(v)
            )
            for i, v in enumerate(resultado.valores)
        ]
        return resultado

    # ── Divergência de quantidades ────────────────────────────
    if n_col == 0:
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append("Nenhuma coluna identificada na lista de colunas.")

    if n_val == 0:
        resultado.status = StatusValidacao.ERRO
        resultado.erros.append("Nenhum valor identificado na cláusula VALUES.")

    if n_col > n_val:
        resultado.status = StatusValidacao.ERRO
        faltando = n_col - n_val
        cols_sem_val = resultado.colunas[n_val:]
        resultado.erros.append(
            f"Mais colunas ({n_col}) do que valores ({n_val}). "
            f"Faltam {faltando} valor(es) para: {', '.join(cols_sem_val)}"
        )
    elif n_val > n_col:
        resultado.status = StatusValidacao.ERRO
        sobrando = n_val - n_col
        vals_extras = resultado.valores[n_col:]
        resultado.erros.append(
            f"Mais valores ({n_val}) do que colunas ({n_col}). "
            f"Sobram {sobrando} valor(es): {', '.join(vals_extras)}"
        )

    # ── Mapeamento coluna ↔ valor ─────────────────────────────
    limite = min(n_col, n_val)
    resultado.mapeamento = [
        MapColVal(
            coluna=resultado.colunas[i],
            valor=resultado.valores[i],
            tipo=inferir_tipo(resultado.valores[i])
        )
        for i in range(limite)
    ]

    # Colunas sem valor
    if n_col > n_val:
        for col in resultado.colunas[n_val:]:
            resultado.mapeamento.append(
                MapColVal(coluna=col, valor="⚠ SEM VALOR", tipo=TipoValor.DESCONHECIDO)
            )

    # Valores sem coluna
    if n_val > n_col:
        for i, val in enumerate(resultado.valores[n_col:], start=n_col + 1):
            resultado.mapeamento.append(
                MapColVal(coluna=f"⚠ SEM COLUNA [{i}]", valor=val, tipo=inferir_tipo(val))
            )

    # Se não havia erros antes, marca OK
    if not resultado.erros:
        resultado.status = StatusValidacao.OK

    return resultado


# ─────────────────────────────────────────────────────────────
# GERAÇÃO DE SUGESTÃO DE CORREÇÃO
# ─────────────────────────────────────────────────────────────

def gerar_sugestao(resultado: ResultadoValidacao) -> str:
    """
    Monta uma versão corrigida/formatada do INSERT
    com base nos dados extraídos.
    """
    if not resultado.tabela:
        return ""

    colunas = resultado.colunas
    valores = resultado.valores
    n_col   = len(colunas)
    n_val   = len(valores)

    # Equilibra as listas para a sugestão
    if n_col > n_val:
        # Preenche valores faltantes com NULL
        valores = valores + ["NULL"] * (n_col - n_val)
    elif n_val > n_col:
        # Trunca valores extras (mantém apenas os mapeáveis)
        valores = valores[:n_col]

    if colunas:
        cols_fmt = ",\n           ".join(colunas)
        vals_fmt = ",\n           ".join(valores)
        sugestao = (
            f"INSERT INTO {resultado.tabela}\n"
            f"          ({cols_fmt})\n"
            f"   VALUES ({vals_fmt});"
        )
    else:
        vals_fmt = ",\n           ".join(valores)
        sugestao = (
            f"INSERT INTO {resultado.tabela}\n"
            f"   VALUES ({vals_fmt});"
        )

    return sugestao


# ─────────────────────────────────────────────────────────────
# EXIBIÇÃO DE RESULTADOS
# ─────────────────────────────────────────────────────────────

def _cor(texto: str, codigo: str) -> str:
    """Aplica cor ANSI se o terminal suportar."""
    CORES = {
        "verde":    "\033[92m",
        "vermelho": "\033[91m",
        "amarelo":  "\033[93m",
        "ciano":    "\033[96m",
        "branco":   "\033[97m",
        "negrito":  "\033[1m",
        "reset":    "\033[0m",
    }
    return f"{CORES.get(codigo, '')}{texto}{CORES['reset']}"


def exibir_resultado(resultado: ResultadoValidacao, indice: int = 1):
    """Exibe o resultado formatado no terminal."""

    print(f"\n{SEPARADOR_DUPLO}")
    print(
        _cor(f"  INSERT #{indice} — {resultado.status.value}", "negrito")
    )
    print(SEPARADOR_DUPLO)

    # ── SQL Original ──────────────────────────────────────────
    print(_cor("  📄 SQL ORIGINAL:", "ciano"))
    print(f"  {resultado.sql_original}")
    print(SEPARADOR_SIMPLES)

    # ── Tabela ────────────────────────────────────────────────
    if resultado.tabela:
        print(f"  🗄️  TABELA  : {_cor(resultado.tabela, 'branco')}")

    # ── Contagem ──────────────────────────────────────────────
    n_col = len(resultado.colunas)
    n_val = len(resultado.valores)
    print(f"  📋 COLUNAS : {_cor(str(n_col), 'amarelo')}")
    print(f"  💾 VALORES : {_cor(str(n_val), 'amarelo')}")
    print(SEPARADOR_SIMPLES)

    # ── Mapeamento ───────────────────────────────────────────
    if resultado.mapeamento:
        print(_cor("  🔗 MAPEAMENTO COLUNA → VALOR:", "ciano"))
        maior_col = max((len(m.coluna) for m in resultado.mapeamento), default=10)
        maior_val = max((len(m.valor)  for m in resultado.mapeamento), default=10)

        for mapa in resultado.mapeamento:
            col  = mapa.coluna.ljust(maior_col)
            val  = mapa.valor.ljust(maior_val)
            tipo = f"[{mapa.tipo.value}]"

            if "⚠" in mapa.coluna or "⚠" in mapa.valor:
                linha = _cor(f"  {col}  →  {val}  {tipo}", "vermelho")
            else:
                linha = f"  {_cor(col, 'branco')}  →  {_cor(val, 'verde')}  {_cor(tipo, 'amarelo')}"

            print(linha)
        print(SEPARADOR_SIMPLES)

    # ── Erros ────────────────────────────────────────────────
    if resultado.erros:
        print(_cor("  ❌ ERROS ENCONTRADOS:", "vermelho"))
        for i, erro in enumerate(resultado.erros, 1):
            print(_cor(f"    [{i}] {erro}", "vermelho"))
        print(SEPARADOR_SIMPLES)

    # ── Avisos ────────────────────────────────────────────────
    if resultado.avisos:
        print(_cor("  ⚠️  AVISOS:", "amarelo"))
        for aviso in resultado.avisos:
            print(_cor(f"    • {aviso}", "amarelo"))
        print(SEPARADOR_SIMPLES)

    # ── Sugestão de correção ──────────────────────────────────
    if resultado.sugestao:
        print(_cor("  💡 SUGESTÃO DE CORREÇÃO:", "ciano"))
        for linha in resultado.sugestao.splitlines():
            print(f"  {linha}")
        print(SEPARADOR_SIMPLES)

    # ── Resumo final ──────────────────────────────────────────
    if resultado.status == StatusValidacao.OK:
        print(_cor("  ✅ INSERT válido e consistente!", "verde"))
    else:
        print(_cor("  ❌ INSERT contém erros. Revise antes de executar.", "vermelho"))

    print(SEPARADOR_DUPLO)


# ─────────────────────────────────────────────────────────────
# PIPELINE PRINCIPAL
# ─────────────────────────────────────────────────────────────

def processar_insert(sql: str, indice: int = 1):
    """
    Pipeline completo: parse → validação → sugestão → exibição.
    """
    resultado = parse_insert(sql)
    resultado = validar_consistencia(resultado)

    if resultado.erros:
        resultado.sugestao = gerar_sugestao(resultado)

    exibir_resultado(resultado, indice)
    return resultado


def separar_multiplos_inserts(texto: str) -> list[str]:
    """
    Divide um bloco de texto contendo múltiplos INSERTs.
    Usa ';' como delimitador, mas trata strings corretamente.
    """
    inserts = []
    buf = []
    em_string = False
    char_str  = ''

    for ch in texto:
        if em_string:
            buf.append(ch)
            if ch == char_str:
                em_string = False
        elif ch in ("'", '"'):
            em_string = True
            char_str  = ch
            buf.append(ch)
        elif ch == ';':
            candidato = ''.join(buf).strip()
            if candidato:
                inserts.append(candidato)
            buf = []
        else:
            buf.append(ch)

    # Último comando sem ';'
    candidato = ''.join(buf).strip()
    if candidato:
        inserts.append(candidato)

    # Filtra somente os que contêm INSERT INTO
    return [
        s for s in inserts
        if re.search(r'\bINSERT\s+INTO\b', s, re.IGNORECASE)
    ]


# ─────────────────────────────────────────────────────────────
# CLI INTERATIVA
# ─────────────────────────────────────────────────────────────

BANNER = r"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║        ██████  ██████  ██                                    ║
║       ██      ██    ██ ██                                    ║
║        █████  ██    ██ ██                                    ║
║            ██ ██ ▄▄ ██ ██                                    ║
║       ██████   ██████  ███████                               ║
║                   ▀▀                                         ║
║       INSERT VALIDATOR  v1.0  ·  Analista PL/SQL             ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""

MENU = """
  [1] Inserir SQL manualmente (modo interativo)
  [2] Processar múltiplos INSERTs (cole e finalize com END)
  [3] Carregar INSERT de arquivo .sql
  [4] Executar exemplos de demonstração
  [0] Sair
"""

EXEMPLOS = [
    # Válido
    "INSERT INTO CLIENTES (ID, NOME, EMAIL, DT_CADASTRO) "
    "VALUES (101, 'João Silva', 'joao@email.com', '2024-03-15');",

    # Mais colunas que valores
    "INSERT INTO PEDIDOS (ID_PEDIDO, ID_CLIENTE, VALOR, STATUS, DT_PEDIDO) "
    "VALUES (999, 42, 150.00);",

    # Mais valores que colunas
    "INSERT INTO PRODUTOS (COD, DESCRICAO) "
    "VALUES (1, 'Notebook', 3500.00, 'ATIVO', 'TI');",

    # Sem lista de colunas
    "INSERT INTO LOG_ACESSO VALUES (SYSDATE, 'USER01', 'LOGIN', NULL);",

    # Tipos variados
    "INSERT INTO FUNCIONARIOS (MAT, NOME, SALARIO, ATIVO, DT_ADMISSAO) "
    "VALUES (7890, 'Maria Souza', 5420.75, TRUE, TO_DATE('2020-06-01','YYYY-MM-DD'));",

    # Erro de sintaxe: parêntese faltando
    "INSERT INTO TESTE (A, B, C VALUES (1, 2, 3);",
]


def modo_interativo():
    print(_cor("\n  Cole seu INSERT SQL abaixo (ENTER duas vezes para validar):\n", "ciano"))
    linhas = []
    while True:
        try:
            linha = input()
        except EOFError:
            break
        if linha == "" and linhas and linhas[-1] == "":
            break
        linhas.append(linha)

    sql = "\n".join(linhas).strip()
    if sql:
        processar_insert(sql)
    else:
        print(_cor("  Nenhum SQL informado.", "amarelo"))


def modo_multiplos():
    print(_cor(
        "\n  Cole múltiplos INSERTs (separados por ';'). "
        "Digite END em uma linha vazia para processar:\n", "ciano"
    ))
    linhas = []
    while True:
        try:
            linha = input()
        except EOFError:
            break
        if linha.strip().upper() == "END":
            break
        linhas.append(linha)

    bloco = "\n".join(linhas)
    inserts = separar_multiplos_inserts(bloco)

    if not inserts:
        print(_cor("  Nenhum INSERT encontrado no bloco.", "amarelo"))
        return

    print(_cor(f"\n  {len(inserts)} INSERT(s) encontrado(s).", "verde"))
    for i, sql in enumerate(inserts, 1):
        processar_insert(sql, indice=i)


def modo_arquivo():
    print(_cor("\n  Informe o caminho do arquivo .sql: ", "ciano"), end="")
    caminho = input().strip().strip('"').strip("'")
    try:
        with open(caminho, encoding="utf-8") as f:
            conteudo = f.read()
        inserts = separar_multiplos_inserts(conteudo)
        if not inserts:
            print(_cor("  Nenhum INSERT encontrado no arquivo.", "amarelo"))
            return
        print(_cor(f"\n  {len(inserts)} INSERT(s) encontrado(s) no arquivo.", "verde"))
        for i, sql in enumerate(inserts, 1):
            processar_insert(sql, indice=i)
    except FileNotFoundError:
        print(_cor(f"  ❌ Arquivo não encontrado: {caminho}", "vermelho"))
    except Exception as ex:
        print(_cor(f"  ❌ Erro ao ler arquivo: {ex}", "vermelho"))


def modo_exemplos():
    print(_cor(f"\n  Executando {len(EXEMPLOS)} exemplo(s) de demonstração...", "ciano"))
    for i, sql in enumerate(EXEMPLOS, 1):
        processar_insert(sql, indice=i)


def cli():
    """Loop principal da CLI interativa."""
    print(_cor(BANNER, "ciano"))

    while True:
        print(_cor(MENU, "branco"))
        try:
            opcao = input("  Escolha uma opção: ").strip()
        except (EOFError, KeyboardInterrupt):
            opcao = "0"

        if opcao == "1":
            modo_interativo()
        elif opcao == "2":
            modo_multiplos()
        elif opcao == "3":
            modo_arquivo()
        elif opcao == "4":
            modo_exemplos()
        elif opcao == "0":
            print(_cor("\n  Encerrando SQL Insert Validator. Até logo!\n", "ciano"))
            sys.exit(0)
        else:
            print(_cor("  Opção inválida. Tente novamente.", "amarelo"))


# ─────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    # Permite passar SQL via argumento de linha de comando:
    # python validator.py "INSERT INTO T (A) VALUES (1);"
    if len(sys.argv) > 1:
        sql_arg = " ".join(sys.argv[1:])
        inserts = separar_multiplos_inserts(sql_arg)
        if inserts:
            for idx, s in enumerate(inserts, 1):
                processar_insert(s, indice=idx)
        else:
            processar_insert(sql_arg)
    else:
        cli()
